package com.mycompany.utilitatsarray;

/**
 * Exercicis resolts Bloc 4 Exercici 3
 *
 * @author dsb i avf
 */
public class UtilitatsArray {

    public static void mostraArray(int[] vector) {
        System.out.println("Elements de l'array: ");
        for (int i = 0; i < vector.length; i++) {
            System.out.print(vector[i] + "\t");
        }
        System.out.println();
    }

    public static void mostraArray(float[] vector) {
        System.out.println("Elements de l'array: ");
        for (int i = 0; i < vector.length; i++) {
            System.out.print(vector[i] + "\t");
        }
        System.out.println();
    }

    public static void mostraArray(double[] vector) {
        System.out.println("Elements de l'array: ");
        for (int i = 0; i < vector.length; i++) {
            System.out.print(vector[i] + "\t");
        }
        System.out.println();
    }

}
