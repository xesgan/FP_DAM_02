package roig.videoclub.controller;

import java.time.LocalDate;
import java.util.Scanner;
import roig.videoclub.model.Director;
import roig.utilities.Utility;
import roig.videoclub.model.Film;

/**
 * La clase MenuController gestiona la lógica de las opciones del menú principal
 * de la aplicación de videoclub. Permite crear y manipular objetos Director y
 * Film, mostrando sus datos, modificando atributos como premios o valoración de
 * espectadores, y generando reportes de clasificación. Utiliza validaciones de
 * entrada a través de métodos auxiliares y controla errores para garantizar
 * datos consistentes.
 *
 * @author Metku - Elias Roig
 */
public class MenuController {

    private static Scanner sc = new Scanner(System.in);
    private static Director director = null;
    private static Film film = null;

    private static final int maxFilms = 40;
    private static ArrayPeliculas arrayPeliculas = new ArrayPeliculas(maxFilms);

    public static void createDirector() {
        try {
            String directorName = Utility.validateDirectorName();
            LocalDate dirBirthDate = Utility.validateDirBirthDate();
            int dirAwardsNum = Utility.validateDirAwardsNum();
            int dirLastFilmDirected = Utility.validateDirLastFilmDirected();

            director = new Director(directorName, dirBirthDate, dirAwardsNum, dirLastFilmDirected);
            System.out.println("[[=== Director created succesfully ===]]\n");
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    public static void showDirectorData() {
        if (director != null) {
            System.out.println("\n=== All director data ===");
            System.out.println(director.toString() + "Director age: " + Utility.directorAge(director) + " years old.");
            System.out.println("=========================\n");
        } else {
            System.out.println("\n=================================");
            System.out.println("There's no Director created yet.");
            System.out.println("=================================\n");
        }
    }

    public static void increaseDirectorAwards() {
        int increase = 0;

        if (director == null) {
            System.out.println("\n=================================");
            System.out.println("There's no Director created yet.");
            System.out.println("=================================\n");
            return;
        }

        System.out.println("\n====================================================");
        System.out.print("[=] Do you want to substract awards? (y/n) : ");
        String substract = sc.nextLine().trim().toLowerCase();
        System.out.println("====================================================");

        while (!substract.equals("y") && !substract.equals("n")) {
            System.out.println("Error: Please, introduce 'y' or 'n' to continue.");
            substract = sc.nextLine().trim().toLowerCase();
        }

        if (director != null && substract.equals("n")) {
            increase = Utility.validateDirAwardsNum();
            director.setAwardsNum(director.getAwardsNum() + increase);
            System.out.println("Succes: [ Adding ] new director's awards amount: " + director.getAwardsNum() + "\n");
        } else if (director != null && substract.equals("y")) {
            increase = Utility.validateDirAwardsNum();
            director.setAwardsNum(director.getAwardsNum() - increase);
            System.out.println("Succes: [ Substracting ] new director's awards amount: " + director.getAwardsNum() + "\n");
        }
    }

    public static void createFilm() {
        try {
            String filmName = Utility.validateFilmName();
            int filmMinutes = Utility.duration();
            int spectatorNum = Utility.spectators();
            double specValoration = Utility.filmValoration();
            boolean suitableForAll = Utility.suitableForAll();
            String spectRatingString = Utility.specRatingString();
            String directorFilmName = Utility.validateDirectorName();

            film = new Film(filmName, filmMinutes, spectatorNum, specValoration, suitableForAll, spectRatingString, directorFilmName);
            System.out.println("\n[[=== Film created successfully ===]]\n");

            boolean added = arrayPeliculas.addPelicula(film);
            if (!added) {
                System.out.println("Error: Could not add film, array might be full.");
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    public static void showFilmData() {

        arrayPeliculas.allFilmData();
    }

    public static void modifyFilmSpectatorRating() {
        if (film == null) {
            System.out.println("\n======================================");
            System.out.println("Error: There's no film data.");
            System.out.println("======================================\n");
            return;
        }
        System.out.println("Insert the title you are looking for: ");
        String input = sc.nextLine();

        Film[] matchingFilms = arrayPeliculas.getFilms(input);

        if (matchingFilms.length == 0) {
            System.out.println("\n======================================");
            System.out.println("Error: No films found with that title");
            System.out.println("======================================\n");
            return;
        }

        film = matchingFilms[0]; // Tomamos la primera coincidencia
        double modifyRating = Utility.validateSpecRating();
        film.setSpectatorValoration(modifyRating);

        System.out.println("Success: New film rating for '" + film.getTitle() + "': "
                + film.getSpectatorValoration() + "\n");
    }

    public static void showFilmClassification() {
        if (film == null) {
            System.out.println("\n======================================");
            System.out.println("Error: There's no film data.");
            System.out.println("======================================\n");
            return;
        }

        System.out.println("Insert the title you are looking for: ");
        String input = sc.nextLine();

        Film[] matchingFilms = arrayPeliculas.getFilms(input);

        if (matchingFilms.length == 0) {
            System.out.println("\n======================================");
            System.out.println("Error: No films found with that title");
            System.out.println("======================================\n");
            return;
        } else {
            Utility.generateReport(film, director);
        }

        film = matchingFilms[0];

    }

    public static void showBestRatingFilms() throws IllegalArgumentException {
        if (film == null) {
            System.out.println("\n======================================");
            System.out.println("Error: There's no film data.");
            System.out.println("======================================\n");
            return;
        }

        System.out.println("\n================="
                + "\nWhat rating are you looking for?"
                + "\n1. Excellent"
                + "\n2. Good"
                + "\n3. Not recommended"
                + "\n4. Unknown"
                + "\n=================");

        while (true) {
            System.out.println("Choose one option: (1-4)");
            String input = sc.nextLine();
            int option;

            // Validación del input para evitar fallos al introducir algo no numérico
            try {
                option = Integer.parseInt(input);
            } catch (NumberFormatException e) {
                System.out.println("Error: Please enter a valid number between 1 and 4.");
                continue; // Repetir la solicitud de entrada
            }

            if (option < 1 || option > 4) {
                System.out.println("Error: Input must be between 1 and 4. Please try again.");
            } else {
                System.out.println("\n======================================"
                        + "\nSuccess: processing films with the selected rating...");
                String rating = switch (option) {
                    case 1 ->
                        "Excellent";
                    case 2 ->
                        "Good";
                    case 3 ->
                        "Not recommended";
                    case 4 ->
                        "Unknown";
                    default ->
                        null;
                };

                Film[] matchingRatingFilms = arrayPeliculas.getRating(rating);
                break;
            }
        }
    }

//    public static void showBestRatingFilms() {
//        if (film == null) {
//            System.out.println("\n======================================");
//            System.out.println("Error: There's no film data.");
//            System.out.println("======================================\n");
//            return;
//        }
//
//        System.out.println("\n================="
//                + "\nWhat rating are you looking for?"
//                + "\n1. Excellent"
//                + "\n2. Good"
//                + "\n3. Not recommended"
//                + "\n4. Unknown"
//                + "\n================="
//                + "Choose one option: (1-4)");
//
//        int input = sc.nextInt();
//        String rating = switch (input) {
//            case 1 ->
//                "Excellent";
//            case 2 ->
//                "Good";
//            case 3 ->
//                "Not recommended";
//            case 4 ->
//                "Unknown";
//            default ->
//                null;
//        };
//
//        if (rating == null) {
//            System.out.println("======================================\n");
//            System.out.println("Error: Invalid rating input");
//            System.out.println("\n======================================\n");
//            return;
//        }
//
//        Film[] matchingRatingFilms = arrayPeliculas.getRating(rating);
//
//        if (matchingRatingFilms.length == 0) {
//            System.out.println("======================================\n");
//            System.out.println("Error: No films found with that rating");
//            System.out.println("\n======================================\n");
//            return;
//        }
//    }

    public static void testFilms() {
        arrayPeliculas.addPelicula(new Film("Film A", 120, 600000, 9.0, true, "Excellent", "Director A"));
        arrayPeliculas.addPelicula(new Film("Film B", 100, 30000, 6.5, true, "Good", "Director B"));
        arrayPeliculas.addPelicula(new Film("Film C", 90, 15000, 4.0, false, "Not recommended", "Director C"));
        arrayPeliculas.addPelicula(new Film("Film D", 80, 5000, 7.0, true, "Unknown", "Director D"));

        System.out.println("=== Running test ===");
        arrayPeliculas.printAllFilms();

        Film[] matches = arrayPeliculas.getRating("Excellent");
        System.out.println("Matches for 'Excellent': " + matches.length);
    }

}
