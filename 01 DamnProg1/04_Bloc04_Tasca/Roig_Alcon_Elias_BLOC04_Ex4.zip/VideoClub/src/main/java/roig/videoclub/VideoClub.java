package roig.videoclub;

import java.util.Scanner;
import roig.utilities.Utility;
import static roig.videoclub.controller.MenuController.createDirector;
import static roig.videoclub.controller.MenuController.createFilm;
import static roig.videoclub.controller.MenuController.increaseDirectorAwards;
import static roig.videoclub.controller.MenuController.modifyFilmSpectatorRating;
import static roig.videoclub.controller.MenuController.showBestRatingFilms;
import static roig.videoclub.controller.MenuController.showDirectorData;
import static roig.videoclub.controller.MenuController.showFilmClassification;
import static roig.videoclub.controller.MenuController.showFilmData;

/**
 * La clase VideoClub actúa como el punto de entrada de la aplicación,
 * gestionando un menú interactivo que permite a los usuarios realizar acciones
 * relacionadas con directores y películas, como crear registros, mostrar
 * información, modificar datos y clasificar películas. Utiliza un bucle
 * do-while para mantener la interacción hasta que el usuario decida salir.
 *
 * @author Metku - Elias Roig
 */
public class VideoClub {

    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        menu();
    }

    public static void menu() {
        int option = 0;

        do {
            System.out.println("=== Choose an option: ==="
                    + "\n1. Create a Director"
                    + "\n2. Show Director data"
                    + "\n3. Increase director's awards"
                    + "\n4. Create a film"
                    + "\n5. Show film data"
                    + "\n6. Modify film spectator rating"
                    + "\n7. Show film classification"
                    + "\n8. Show best films."
                    + "\n9. Exit");
            System.out.print("=== Option desired: ");

            option = Utility.validateInt();

            switch (option) {
                case 1 ->
                    createDirector();
                case 2 ->
                    showDirectorData();
                case 3 ->
                    increaseDirectorAwards();
                case 4 ->
                    createFilm();
                case 5 ->
                    showFilmData();
                case 6 ->
                    modifyFilmSpectatorRating();
//                        MenuController.testFilms();
                case 7 ->
                    showFilmClassification();
                case 8 ->
                    showBestRatingFilms();
                case 9 -> {
                    System.out.println("\n======================================");
                    System.out.println("Thank you for using the app. Farewell!");
                    System.out.println("======================================\n");
                    System.exit(0);
                }
                default ->
                    throw new AssertionError();
            }
        } while (option != 0);
    }

}
