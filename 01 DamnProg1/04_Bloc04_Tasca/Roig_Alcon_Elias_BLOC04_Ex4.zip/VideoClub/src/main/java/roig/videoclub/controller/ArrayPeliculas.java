/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package roig.videoclub.controller;

import roig.videoclub.model.Film;

/**
 * Esta práctica de Java implementa un sistema de gestión de películas que
 * almacena películas en un array de tamaño fijo, muestra datos de películas,
 * busca por título o clasificación, y agrega nuevas películas. La clase
 * ArrayPeliculas maneja estas operaciones con validaciones básicas.
 *
 * @author Metku - Elias Roig
 */
public class ArrayPeliculas {

    private Film[] films;
    private int numFilms;

    // Constructor
    public ArrayPeliculas(int maxFilms) {
        films = new Film[maxFilms];
        numFilms = 0;
    }

    public int allFilmData() {
        if (numFilms == 0) {
            System.out.println("\n======================================");
            System.out.println("Error: There's no film data.");
            System.out.println("======================================\n");
        } else {
            for (int i = 0; i < numFilms; i++) {
                System.out.println("======================================\n");
                System.out.println(films[i]);
                System.out.println("\n======================================\n");
            }
        }
        return numFilms;
    }

    public Film[] getFilms(String title) {
        // Count matching films first
        int count = 0;
        for (int i = 0; i < numFilms; i++) {
            if (films[i].getTitle().toLowerCase().matches(title.toLowerCase())) {
                count++;
            }
        }

        // Create array with exact size
        Film[] matches = new Film[count];
        int index = 0;

        // Fill array with matching films doing a copy of it
        for (int i = 0; i < numFilms; i++) {
            if (films[i].getTitle().toLowerCase().matches(title.toLowerCase())) {
                matches[index++] = films[i];

            }
        }
        System.out.println("Films found: " + count);
        return matches;
    }

    public int getNumFilms() {
        return numFilms;
    }

    public boolean addPelicula(Film nuevo) {
        if (numFilms < films.length) {
            films[numFilms] = nuevo;
            numFilms++;
            return true;
        } else {
            System.out.println("Error: Film array is full.");
            return false;
        }
    }

    public Film[] getRating(String rating) {
        System.out.println("Searching for films with rating: " + rating);
        int count = 0;

        // Contar coincidencias
        for (int i = 0; i < numFilms; i++) {
            if (films[i].getSpecRatingString().equalsIgnoreCase(rating)) {
                System.out.println("======================================");
                System.out.println("\nMatch found: " + films[i].toString()); // Depuración
                System.out.println("\n======================================");
                count++;
            }
        }

        if (count == 0) {
            System.out.println("======================================");
            System.out.println("No matches found for rating: " + rating);
        }

        // Crear un arreglo de coincidencias
        Film[] matches = new Film[count];
        int index = 0;

        for (int i = 0; i < numFilms; i++) {
            if (films[i].getSpecRatingString().equalsIgnoreCase(rating)) {
                matches[index++] = films[i];
            }
        }
        System.out.println("Films found with this title: " + count);
        System.out.println("======================================\n");
        return matches;
    }

    public void printAllFilms() {
        if (numFilms == 0) {
            System.out.println("No films are currently stored.");
        } else {
            System.out.println("=== Films in the system ===");
            for (int i = 0; i < numFilms; i++) {
                System.out.println(films[i].toString());
            }
        }
    }
}
