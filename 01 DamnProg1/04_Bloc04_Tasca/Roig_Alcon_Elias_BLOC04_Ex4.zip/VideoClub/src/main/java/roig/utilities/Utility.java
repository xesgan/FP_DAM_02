package roig.utilities;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.InputMismatchException;
import java.util.Scanner;
import roig.videoclub.model.Director;
import roig.videoclub.model.Film;

/**
 * La clase Utility proporciona métodos para validar y obtener datos
 * relacionados con directores y películas, como nombres, fechas, premios,
 * duraciones y espectadores, garantizando que los datos ingresados cumplan con
 * formatos y rangos adecuados antes de ser utilizados en la aplicación.
 *
 * @author Metku - Elias Roig
 */
public class Utility {

    private static final Scanner sc = new Scanner(System.in);
    private static String specRating;
    private static double filmRating;
    private static int totalAwards = 0;

    public static int validateInt() {

        while (true) {
            try {
                int option = Integer.parseInt(sc.nextLine());
                if (option < 1 || option > 9) {
                    System.out.println("""
                                        ======================================
                                            Option must be between 1 and 9
                                        ======================================""");
                    System.out.print("Try again: ");
                } else {
                    return option;
                }
            } catch (NumberFormatException e) {
                System.out.print("Error: Please enter a valid integer. Try again:");
            }
        }
    }

    public static String validateDirectorName() {
        System.out.println("\n=== Set Director's Name ===");

        while (true) {
            System.out.print("Enter director's name: ");
            String directorName = sc.nextLine().trim();

            if (directorName.isEmpty() || directorName.isBlank()) {
                System.out.println("Error: Name cannot be empty.");
            } else if (!directorName.matches("[a-zA-Z ]+")) {
                System.out.println("Error: Name must contain only letters(50) and spaces.");
            } else if (directorName.split("\\s+").length != 2) {
                System.out.println("Error: Please provide both first name and last name.");
            } else if (directorName.length() > 50) {
                System.out.println("Error: Name length must not exceed 50 characters.");
            } else {
                System.out.println("Success: Director's name set.");
                return directorName;
            }
        }
    }

    public static LocalDate validateDirBirthDate() {
        System.out.println("\n=== Set Director's Birthdate ===");
        System.out.println("Format: dd/MM/yyyy");

        LocalDate dirBirthDate = null;
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

        while (true) {
            System.out.print("Enter birthdate: ");
            String input = sc.nextLine().trim();

            try {
                dirBirthDate = LocalDate.parse(input, formatter);
                System.out.println("Success: Birthdate set to " + dirBirthDate.format(formatter));
                break;
            } catch (DateTimeParseException e) {
                System.out.println("Error: Invalid date format. Please use dd/MM/yyyy.");
            }
        }
        return dirBirthDate;
    }

    public static int validateDirAwardsNum() {
        System.out.println("\n=== Set Director's Awards ===");

        while (true) {
            try {
                System.out.print("Enter number of awards: ");
                int dirAwardsNum = Integer.parseInt(sc.nextLine());
                if (dirAwardsNum < 0) {
                    System.out.println("Error: Awards must be 0 or a positive integer.");
                } else {
                    return dirAwardsNum;
                }
            } catch (NumberFormatException e) {
                System.out.println("Error: Please enter a valid integer.");
            }
        }
    }

    public static int substractAwards() {
        System.out.println("\n=== Set Director's Awards ===");

        while (true) {
            try {
                System.out.print("Enter number of awards: ");
                int dirAwardsNum = Integer.parseInt(sc.nextLine());
                if (dirAwardsNum < 0) {
                    System.out.println("Error: Awards must be 0 or a positive integer.");
                } else {
                    System.out.println("Success: Awards set to " + dirAwardsNum + "\n");
                    return dirAwardsNum;
                }
            } catch (NumberFormatException e) {
                System.out.println("Error: Please enter a valid integer.");
            }
        }
    }

    public static int validateDirLastFilmDirected() {
        System.out.println("\n=== Set the last film directed year ===");
        int dirLastFilmDirected = 0;
        LocalDateTime currentYear = LocalDateTime.now();

        while (true) {
            try {
                System.out.print("Enter director last film year: ");
                dirLastFilmDirected = Integer.parseInt(sc.nextLine());
                if (dirLastFilmDirected >= 1895 && dirLastFilmDirected <= currentYear.getYear()) {
                    System.out.println("Success: setting last film directed year...\n");
                    break;
                } else {
                    System.out.println("Error: Introduce a realistic year. Try again...");
                }
            } catch (Exception e) {
                System.out.println(e.getMessage() + " must be an integer.");
            }
        }
        return dirLastFilmDirected;
    }

    public static int directorAge(Director director) {
        if (director != null) {
            LocalDate actual = LocalDate.now();
            LocalDate BirthDate = director.getBirthDate();
            return Period.between(BirthDate, actual).getYears();
        } else {
            System.out.println("No Director created...");
            return -1;
        }
    }

    public static String validateFilmName() {

        System.out.println("\n=== Set Film name ===");

        while (true) {
            System.out.print("Enter film name: ");
            String filmName = sc.nextLine().trim();

            if (filmName.length() > 0 && filmName.length() <= 100) {
                System.out.println("Succes: setting film name correctly...\n");
                return filmName;
            } else if (filmName.trim().split(" ").length != 2) {
                System.out.println("Error: please enter both first name and last name.");
            } else {
                System.out.println("Error: the name should'tn be larger than 100 characters.");
            }
        }
    }

    public static int duration() {
        System.out.println("=== Introduce Film duration in minutes ===");

        while (true) {
            try {
                System.out.print("Enter film duration: ");
                int duration = Integer.parseInt(sc.nextLine());
                if (duration > 0 && duration < 320) {
                    System.out.println("Succes: setting film duration...\n");
                    return duration;
                } else {
                    System.out.println("Error: duration can't be negative or more than 320 minutes.");
                }
            } catch (Exception e) {
                System.out.println(e.getMessage() + " must be an integer.");
            }
        }
    }

    private static int spectatorsNum;

    public static int spectators() {
        System.out.println("""
                           === Introduce Film spectators number ===
                           ----------------------------------------
                           [ 10 thousand spectators can't rate a film. ]
                           [ 500 thousand spectators can get an exellent rating. ]
                           ----------------------------------------""");

        while (true) {
            try {
                System.out.print("Enter number of viewers: ");
                spectatorsNum = Integer.parseInt(sc.nextLine());
                if (spectatorsNum < 0) {
                    System.out.println("Error: must be 0 or positive!");
                } else {
                    System.out.println("Succes: setting spectators!\n");
                    break;
                }
            } catch (NumberFormatException e) {
                System.out.println(e.getMessage() + " Spectators can't be cut in half.");
            }
        }
        return spectatorsNum;
    }

    public static double filmValoration() {
        System.out.println("=== Set the film valoration ===");

        while (true) {
            try {
                System.out.print("Enter the film rating (0.0 to 10.0): ");
                filmRating = sc.nextDouble();

                if (filmRating < 0.0 || filmRating > 10.0) {
                    System.out.println("Error: rating must be between 0.0 and 10.0. Try again.");
                    continue; // Volver al inicio del bucle
                }

                specRating = calculateRating(filmRating, spectatorsNum);

                System.out.println("This is the current rating of the film: " + filmRating
                        + ". \nReviews from moviegoers told: " + spectatorsNum + ".");

                break;

            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a valid number. Error: " + e.getMessage());
                sc.next(); // Limpiar la entrada no válida
            }
        }
        sc.nextLine();
        return filmRating;
    }

    private static String calculateRating(double filmRating, int spectatorsNum) {
        // Verificación inicial de número de espectadores
        if (spectatorsNum < 10000) {
            return "Unknown";
        }

        // Películas con alta audiencia y excelente valoración
        if (spectatorsNum >= 500000 && filmRating >= 8.0) {
            return "Excellent";
        }

        // Películas con audiencia media
        if (spectatorsNum >= 10000 && spectatorsNum < 500000) {
            if (filmRating >= 5.5) {
                return "Good";
            }
            return "Not recommended";
        }
        return "Unknown";
    }

    public static String specRatingString() {
        return specRating;
    }

    public static boolean suitableForAll() {

        System.out.println("\n====================================================");
        System.out.print("[=] Is the film suitable for all public? (y/n) : ");
        String suitable = sc.nextLine().trim().toLowerCase();
        System.out.println("====================================================");

        while (!suitable.equals("y") && !suitable.equals("n")) {
            System.out.println("Error: Please, introduce 'y' or 'n' to continue.");
            suitable = sc.nextLine().trim().toLowerCase();
        }
        return suitable.equals("y");

    }

    public static double validateSpecRating() {

        System.out.println("\n=== Set up new spectator rating ===");
        double specRating = 0.0;

        while (true) {
            try {
                System.out.print("Enter viewer rating: ");
                specRating = Double.parseDouble(sc.nextLine());
                if (specRating < 0.0 || specRating > 10.0) {
                    System.out.println("Error: Must be positive or not higher than 10!");
                } else {
                    System.out.println("Succes: Setting new spectator rating!");
                    break;
                }
            } catch (Exception e) {
                System.out.println(e.getMessage() + " must be a double.");
            }
        }
        return specRating;
    }

    public static void generateReport(Film film, Director director) {
        System.out.println("\n=== Movie Classification Report ===");

        if (film == null) {
            System.out.println("Error: No movie has been created.");
            return;
        }
        if (director == null) {
            System.out.println("Error: No director has been created.");
            return;
        }

        if (!film.getDirectorFilmName().equals(director.getDirectorName())) {
            System.out.println("\nError: Director's name doesn't match in both objects.\n");
        } else {
            System.out.println("Succes: Director's name matches.");
        }

        String userName = "Elias Roig Alcon";
        String corporativeEmail = "eliasroig@paucasesnovescifp.cat";

        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String timestamp = now.format(formatter);

        int directorAge = Utility.directorAge(director);

        StringBuilder report = new StringBuilder();
        report.append("\nCalculation date and time: ").append(timestamp).append("\n");
        report.append("User: ").append(userName).append(" | Email: ").append(corporativeEmail).append("\n");
        report.append("\n--- Movie Details ---\n");
        report.append("Title: ").append(film.getTitle()).append("\n");
        report.append("Duration: ").append(film.getMinutes()).append(" minutes\n");
        report.append("Director: ").append(director.getDirectorName()).append(" (Age: ").append(directorAge).append(")\n");
        report.append("Classification: ").append(specRatingString()).append("\n");
        report.append("Viewers: ").append(film.getSpectatorsNum()).append("\n");
        report.append("Viewer rating: ").append(film.getSpectatorValoration()).append("\n");
        report.append("----------------------\n");

        System.out.println(report.toString());
    }
}
