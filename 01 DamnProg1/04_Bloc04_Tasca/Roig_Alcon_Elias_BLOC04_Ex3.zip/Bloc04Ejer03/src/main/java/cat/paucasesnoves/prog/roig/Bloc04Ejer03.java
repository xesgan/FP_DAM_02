package cat.paucasesnoves.prog.roig;

import java.util.Scanner;

/**
 * Este programa crea una matriz 3x2 de números decimales con valores
 * introducidos por el usuario. Muestra una tabla con los valores y el máximo de
 * cada fila.
 *
 * @author Metku
 */

public class Bloc04Ejer03 {

    public static void main(String[] args) {
        // Crear la matriz
        double[][] matriz = new double[3][2];
        Scanner sc = new Scanner(System.in);

        // Rellenar la matriz
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                boolean valorValido = false;

                while (!valorValido) {
                    try {
                        System.out.println("Introduce los valores de la matriz [" + i + "][" + j + "]");
                        matriz[i][j] = sc.nextDouble();
                        valorValido = true;
                    } catch (Exception e) {
                        System.out.println("Error: Por favor, introduce un valor numérico válido.");
                        sc.nextLine(); // Limpiar el buffer
                    }
                }
            }
        }

        // Imprimir encabezado
        System.out.printf("%10s %10s %10s%n", "columna1", "columna2", "máximo");
        System.out.println();

        // Imprimir matriz con formato
        for (int i = 0; i < matriz.length; i++) {
            System.out.printf("fila%-5d", (i + 1));
            double maxFila = matriz[i][0];

            for (int j = 0; j < matriz[i].length; j++) {
                System.out.printf("%10.1f", matriz[i][j]);
                if (matriz[i][j] > maxFila) {
                    maxFila = matriz[i][j];
                }
            }
            System.out.printf("%15.0f%n", maxFila);
            System.out.println();
        }
    }
}
