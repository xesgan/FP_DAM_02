/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package cat.paucasesnoves.prog.roig.Bloc04Ejer01;

import java.util.Scanner;

/**
 * Este programa Java solicita al usuario una frase y un car�cter, y cuenta
 * cu�ntas veces aparece dicho car�cter en la frase. Incluye validaciones
 * b�sicas de entrada y est� organizado en m�todos independientes para cada
 * funci�n.
 *
 * @author Metku
 */

public class Bloc04Ejer01 {

    private static final Scanner sc = new Scanner(System.in, "ISO-8859-1");
    private static String fraseUser;
    private static char buscarLetra;

    public static void main(String[] args) {

        pedirFrase();
        pedirLetra();
        analizarFrase(fraseUser, buscarLetra);
    }

    public static String pedirFrase() {

        while (true) {
            System.out.println("Introduce la frase que se va a analizar: ");
            fraseUser = sc.nextLine();

            if (fraseUser == null || fraseUser.trim().isEmpty()) {
                System.out.println("Debes escribir una frase completa.");
            } else if (fraseUser.length() > 50) {
                System.out.println("Escribe una frase m�s corta. (m�x 50)");
            } else {
                System.out.println("Frase guardada.");
                break;
            }
        }
        return fraseUser;
    }

    private static char pedirLetra() {

        System.out.println("Introduce la letra que quieres analizar en la frase: (N�mero, s�mbolo o letra)");
        buscarLetra = sc.next().charAt(0);
        System.out.println("Car�cter guardado..." + "(" + buscarLetra + ")");
        return buscarLetra;
    }

    private static void analizarFrase(String frase, char caracter) {

        System.out.println("Buscando...");

        int contador = 0;
        for (int i = 0; i < frase.length(); i++) {
            if (frase.charAt(i) == caracter) {
                contador++;
            }
        }
        if (contador >= 1) {
            System.out.println("Ha sido encontrado " + contador + " veces!");
        } else {
            System.out.println("El car�cter " + caracter + " no ha sido encontrado...");
        }
    }
}
