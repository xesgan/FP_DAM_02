package cat.paucasesnoves.prog.roig.Bloc04Ejer02;

import java.util.Scanner;

/**
 * Este programa Java permite al usuario introducir 5 cadenas con formato
 * "123-LLLL", valida cada entrada, y determina si la parte alfabética empieza
 * por 'A'. Almacena los resultados en arrays y muestra un resumen con los
 * totales.
 *
 * @author Metku
 */

public class Bloc04Ejer02 {

    private static Scanner sc = new Scanner(System.in, "ISO-8859-1");
    private static String[] arrayCadenas = new String[5];
    private static boolean[] arrayBooleanos = new boolean[5];
    private static int contadorTrue = 0;
    private static int contadorFalse = 0;

    private static boolean validarFormato(String cadena) {
        return cadena.matches("\\d{3}-[a-zA-Z]{4}");
    }

    private static void almacenarArrayCadena(String[] generarArrayCadenas) {
        System.out.println("Introduce 5 cadenas válidas: (123-LLLL)");
        int count = 0;
        while (count < 5) {
            String cadena = sc.nextLine();
            if (validarFormato(cadena)) {
                arrayCadenas[count] = cadena;
                count++;
            } else {
                System.out.println("Debes introducir un formato válido. Prueba otra vez.");
            }
        }
    }

    private static boolean[] generarArrayBooleanos(String[] arrayCadenaB) {
        boolean[] arrayBooleanos = new boolean[arrayCadenaB.length];

        for (int i = 0; i < arrayCadenaB.length; i++) {
            arrayBooleanos[i] = arrayCadenaB[i].split("-")[1].startsWith("A");
            if (arrayBooleanos[i]) {
                contadorTrue++;
            } else {
                contadorFalse++;
            }
        }
        return arrayBooleanos;
    }

    private static void mostrarArrays(String[] arrayCadenas, boolean[] arrayBoolean) {

        System.out.println("Resultado");
        for (int i = 0; i < arrayCadenas.length; i++) {
            System.out.println(arrayCadenas[i] + "\t\t" + arrayBoolean[i]);
        }
    }

    public static void main(String[] args) {

        almacenarArrayCadena(arrayCadenas);
        arrayBooleanos = generarArrayBooleanos(arrayCadenas);
        mostrarArrays(arrayCadenas, arrayBooleanos);
        System.out.println("Número de true: " + contadorTrue);
        System.out.println("Número de false: " + contadorFalse);
        System.out.println("Programa realizado por Elias Roig.");

    }
}
