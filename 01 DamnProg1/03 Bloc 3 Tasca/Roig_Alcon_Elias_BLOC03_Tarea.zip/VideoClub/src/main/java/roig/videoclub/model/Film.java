package roig.videoclub.model;

/**
 * La clase Film define las propiedades y comportamientos de una película en el
 * sistema del videoclub.
 *
 * @author Metku - Elias Roig
 */
public class Film {

    String title;
    int minutes;
    int spectatorsNum;
    double spectatorValoration;
    boolean allPublicFilm;
    String directorFilmName;
    private static int filmCounter = 0;

    public Film() {

    }

    public Film(String title, int minutes, int spectatorsNum, double spectatorValoration, boolean allPublicFilm, String directorFilmName) {
        this.title = title;
        this.minutes = minutes;
        this.spectatorsNum = spectatorsNum;
        this.spectatorValoration = spectatorValoration;
        this.allPublicFilm = allPublicFilm;
        this.directorFilmName = directorFilmName;
        filmCounter++;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getMinutes() {
        return minutes;
    }

    public void setMinutes(int minutes) {
        this.minutes = minutes;
    }

    public int getSpectatorsNum() {
        return spectatorsNum;
    }

    public void setSpectatorsNum(int spectatorsNum) {
        this.spectatorsNum = spectatorsNum;
    }

    public double getSpectatorValoration() {
        return spectatorValoration;
    }

    public void setSpectatorValoration(double spectatorValoration) {
        this.spectatorValoration = spectatorValoration;
    }

    public boolean isAllPublicFilm() {
        return allPublicFilm;
    }

    public void setAllPublicFilm(boolean allPublicFilm) {
        this.allPublicFilm = allPublicFilm;
    }

    public String getDirectorFilmName() {
        return directorFilmName;
    }

    public void setDirectorFilmName(String directorFilmName) {
        this.directorFilmName = directorFilmName;
    }

    public static int getFilmCounter() {
        return filmCounter;
    }

    public static void setFilmCounter(int filmCounter) {
        Film.filmCounter = filmCounter;
    }

    @Override
    public String toString() {
        return "\nTitle: " + this.getTitle()
                + "\nDuration: " + this.getMinutes()
                + "\nSpectator Number: " + this.getSpectatorsNum()
                + "\nSpectator Film Valoration: " + this.getSpectatorValoration()
                + "\nSuitable for all audience: " + this.isAllPublicFilm()
                + "\nDirector's name: " + this.getDirectorFilmName()
                + "\nFilms created: " + filmCounter;
    }
}
