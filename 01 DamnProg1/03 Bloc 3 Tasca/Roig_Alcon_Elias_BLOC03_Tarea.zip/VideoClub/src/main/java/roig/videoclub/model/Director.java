package roig.videoclub.model;

import java.time.LocalDate;

/**
 * La clase Director define las propiedades y comportamientos de una director en el
 * sistema del videoclub.
 *
 * @author Metku
 */
public class Director {

    String directorName;
    LocalDate birthDate;
    int awardsNum;
    int lastFilmDirectedYear;

    public Director() {
    }

    public Director(String directorName, LocalDate birthDate, int awardsNum, int lastFilmDirectedYear) {
        this.directorName = directorName;
        this.birthDate = birthDate;
        this.awardsNum = awardsNum;
        this.lastFilmDirectedYear = lastFilmDirectedYear;
    }

    public String getDirectorName() {
        return directorName;
    }

    public void setDirectorName(String directorName) {
        this.directorName = directorName;
    }

    public LocalDate getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(LocalDate birthDate) {
        this.birthDate = birthDate;
    }

    public int getAwardsNum() {
        return awardsNum;
    }

    public void setAwardsNum(int awardsNum) {
        this.awardsNum = awardsNum;
    }

    public int getLastFilmDirected() {
        return lastFilmDirectedYear;
    }

    public void setLastFilmDirected(int lastFilmDirectedYear) {
        this.lastFilmDirectedYear = lastFilmDirectedYear;
    }

    @Override
    public String toString() {
        return "Director's data: \n"
                + "Name: " + this.directorName + ".\n"
                + "Birthdate: " + this.birthDate + ".\n"
                + "Awards recieved: " + this.awardsNum + ".\n"
                + "Last film directed year: " + this.lastFilmDirectedYear + ".\n";
    }

}
