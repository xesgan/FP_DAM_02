/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package roig.videoclub;

import java.util.InputMismatchException;
import java.util.Scanner;
import static roig.videoclub.controller.MenuController.createDirector;
import static roig.videoclub.controller.MenuController.createFilm;
import static roig.videoclub.controller.MenuController.increaseDirectorAwards;
import static roig.videoclub.controller.MenuController.modifyFilmSpectatorRating;
import static roig.videoclub.controller.MenuController.showDirectorData;
import static roig.videoclub.controller.MenuController.showFilmClassification;
import static roig.videoclub.controller.MenuController.showFilmData;

/**
 * La clase VideoClub actúa como el punto de entrada de la aplicación,
 * gestionando un menú interactivo que permite a los usuarios realizar acciones
 * relacionadas con directores y películas, como crear registros, mostrar
 * información, modificar datos y clasificar películas. Utiliza un bucle
 * do-while para mantener la interacción hasta que el usuario decida salir.
 *
 * @author Metku - Elias Roig
 */
public class VideoClub {

    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        menu();
    }

    public static void menu() {
        int option = 0;

        do {
            System.out.println("=== Choose an option: ==="
                    + "\n1. Create a Director"
                    + "\n2. Show Director data"
                    + "\n3. Increase director's awards"
                    + "\n4. Create a film"
                    + "\n5. Show film data"
                    + "\n6. Modify film spectator rating"
                    + "\n7. Show film classification"
                    + "\n8. Exit");
            System.out.print("=== Option desired: ");

            try {
                option = sc.nextInt();
                sc.nextLine(); // Limpia el buffer
                while (option < 1 || option > 8) {
                    System.out.print("Error: Please enter a valid option (1-8): ");
                    option = sc.nextInt();
                    sc.nextLine(); // Limpia el buffer
                }
            } catch (InputMismatchException e) {
                System.out.println("Error: Please enter a valid number");
                sc.nextLine(); // Limpia el buffer
                option = 0;
            }

            switch (option) {
                case 1:
                    createDirector();
                    break;
                case 2:
                    showDirectorData();
                    break;
                case 3:
                    increaseDirectorAwards();
                    break;
                case 4:
                    createFilm();
                    break;
                case 5:
                    showFilmData();
                    break;
                case 6:
                    modifyFilmSpectatorRating();
                    break;
                case 7:
                    showFilmClassification();
                    break;
                case 8:
                    System.out.println("\n======================================");
                    System.out.println("Thank you for using the app. Farewell!");
                    System.out.println("======================================\n");
                    System.exit(0);
                    break;
                default:
                    throw new AssertionError();
            }
        } while (option != 0);
    }
}
