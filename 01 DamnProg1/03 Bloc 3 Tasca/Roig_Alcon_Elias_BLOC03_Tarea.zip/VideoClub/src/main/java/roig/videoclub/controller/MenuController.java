package roig.videoclub.controller;

import java.time.LocalDate;
import java.util.Scanner;
import roig.videoclub.model.Director;
import roig.utilities.Utility;
import roig.videoclub.model.Film;

/**
 * La clase MenuController gestiona la lógica de las opciones del menú principal
 * de la aplicación de videoclub. Permite crear y manipular objetos Director y
 * Film, mostrando sus datos, modificando atributos como premios o valoración de
 * espectadores, y generando reportes de clasificación. Utiliza validaciones de
 * entrada a través de métodos auxiliares y controla errores para garantizar
 * datos consistentes.
 *
 * @author Metku - Elias Roig
 */
public class MenuController {

    private static Scanner sc = new Scanner(System.in);
    private static Director director = null;
    private static Film film = null;

    public static void createDirector() {
        try {
            String directorName = Utility.validateDirectorName();
            LocalDate dirBirthDate = Utility.validateDirBirthDate();
            int dirAwardsNum = Utility.validateDirAwardsNum();
            int dirLastFilmDirected = Utility.validateDirLastFilmDirected();

            director = new Director(directorName, dirBirthDate, dirAwardsNum, dirLastFilmDirected);
            System.out.println("[[=== Director created succesfully ===]]\n");
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    public static void showDirectorData() {
        if (director != null) {
            System.out.println("\n=== All director data ===");
            System.out.println(director.toString() + "Director age: " + Utility.directorAge(director) + " years old.");
            System.out.println("=========================\n");
        } else {
            System.out.println("\n=========================\n");
            System.out.println("There's no Director created yet.");
            System.out.println("=========================\n");
        }
    }

    public static void increaseDirectorAwards() {
        int increase = 0;

        System.out.println("\n====================================================");
        System.out.print("[=] Do you want to substract awards? (y/n) : ");
        String substract = sc.nextLine().trim().toLowerCase();
        System.out.println("====================================================");

        while (!substract.equals("y") && !substract.equals("n")) {
            System.out.println("Error: Please, introduce 'y' or 'n' to continue.");
            substract = sc.nextLine().trim().toLowerCase();
        }

        if (director != null && substract.equals("n")) {
            increase = Utility.validateDirAwardsNum();
            director.setAwardsNum(director.getAwardsNum() + increase);
            System.out.println("Succes: [ Adding ] new director's awards amount: " + director.getAwardsNum() + "\n");
        } else if (director != null && substract.equals("y")) {
            increase = Utility.validateDirAwardsNum();
            director.setAwardsNum(director.getAwardsNum() - increase);
            System.out.println("Succes: [ Substracting ] new director's awards amount: " + director.getAwardsNum() + "\n");
        }
    }

    public static void createFilm() {
        try {
            String filmName = Utility.validateFilmName();
            int filmMinutes = Utility.duration();
            int spectatorNum = Utility.spectators();
            double specValoration = Utility.filmValoration();
            boolean suitableForAll = Utility.suitableForAll();
            String directorFilmName = Utility.validateDirectorName();

            film = new Film(filmName, filmMinutes, spectatorNum, specValoration, suitableForAll, directorFilmName);
            System.out.println("\n[[=== Film created succesfully ===]]\n");
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    public static void showFilmData() {
        if (film != null) {
            System.out.println("\n===== All Film data =====");
            System.out.println(film.toString() + ".");
            System.out.println("=========================\n");
        } else {
            System.out.println("\n=========================\n");
            System.out.println("There's no Film created yet.");
            System.out.println("=========================\n");
        }
    }

    public static void modifyFilmSpectatorRating() {
        double modifyRating = 0;

        if (film != null) {
            modifyRating = Utility.validateSpecRating();
            film.setSpectatorValoration(modifyRating);
            System.out.println("Succes: New film rating: " + film.getSpectatorValoration() + "\n");
        }
    }

    public static void showFilmClassification() {
        Utility.generateReport(film, director);
    }

}
