import java.util.Scanner;

/**
 * 1.-Crea un proyecto Maven en Netbeans denominado Bloc01Ejer01 y añade
 * el código necesario para ejecutar el siguiente programa que declara y
 * usa una variable de tipo String, cambiando su valor por tu nombre.
 *
 * @author Metku - Elias Roig
 */
public class Main {
    public static void main(String[] args) {
        String name = "Elias";
        System.out.println("Nombre: " + name + ".");
    }
}