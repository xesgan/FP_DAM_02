/**
 * Write a Java program to print the result of the following operations.
 *
 * Añade un cálculo más (e) que muestre el resultado de restar 6 dividido
 * por 2 al resultado del módulo de 3 entre 2.
 *
 * @author Metku - Elias Roig DAM1
 */

public class Main {
    public static void main(String[] args) {
        // Calculate and print the result of the expression: -5 + 8 * 6
        System.out.println(-5 + 8 * 6);

        // Calculate and print the result of the expression: (55 + 9) % 9
        System.out.println((55 + 9) % 9);

        // Calculate and print the result of the expression: 20 + -3 * 5 / 8
        System.out.println(20 + -3 * 5 / 8);

        // Calculate and print the result of the expression: 5 + 15 / 3 * 2 - 8 % 3
        System.out.println(5 + 15 / 3 * 2 - 8 % 3);

        // Calculate and print the result of the expression: (6 / 2) - (3 % 2)
        System.out.println((6 / 2) - (3 % 2));

        // Esto es una prueba de clonar repositorio
    }
}
