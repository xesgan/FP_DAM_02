package com.mycompany.exesresoltsbloc02exe2;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * Exercici 2 dels Exercicis resolts del Bloc02:
 * Càlcul del factorial amb l'estructura while
 * Es captura l'excepció, es mostra el missatge corresponent i 
 *   es torna a demanar la dada fins que és correcta.
 * @author avf i dsb
 */
public class ExesResoltsBloc02Exe2 {

    public static void main(String[] args) {
        int n;
        double factorial;
        Scanner sc;
        boolean dadaCorrecta;
               
        dadaCorrecta = false;
        do {
            try {
                System.out.print("Introdueix el número: ");
                sc = new Scanner(System.in);
                n = sc.nextInt();              
                factorial = calculaFactorial(n);
                System.out.println("El factorial de " + n + " és: " + factorial);
                dadaCorrecta = true;
            } catch (InputMismatchException e) {              
                System.out.println("S'ha d'introduir un número sencer. Introdueix un nou valor: ");
            }
        } while (!dadaCorrecta);
    }

    public static double calculaFactorial (int n) {
        double factorial;
        int i;
        factorial = 1;
        i = n;
        while (i > 1) {
            factorial = factorial * i;
            i--;
        }
        return factorial;
    }   
    
}
