package com.mycompany.exesresoltsbloc02exe1;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * Exercici1 dels Exercicis Resolts Bloc02: 
 * Càlcul del factorial amb l'estructura for 
 * Es captura l'excepció, es mostra el missatge corresponent i finalitza el programa
 *
 * @author avf i dsb
 */
public class ExesResoltsBloc02Exe1 {

    public static void main(String[] args) {
        int n;
        double factorial;
        Scanner sc;

        try {
            System.out.print("Introdueix el número: ");
            sc = new Scanner(System.in);
            n = sc.nextInt();
            factorial = calculaFactorial(n);
            System.out.println("El factorial de " + n + " és: " + factorial);
        } catch (InputMismatchException e) {
            System.out.println("Per poder calcular el factorial s’ha d’introduir un número sencer.");
        }
    }

    public static double calculaFactorial(int n) {
        double factorial;
        factorial = 1;
        for (int i = n; i > 1; i--) {
            factorial = factorial * i;
            System.out.println(factorial);
        }
        return factorial;
    }

}

