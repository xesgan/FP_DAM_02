package com.mycompany.concessionari;
/**
 * Classe que crea i manipula dos objectes de la classe Vehicle
 * @author avf i dsb
 */
public class Concessionari {

    public static void main(String[] args) {
        
        Vehicle vehicle1; 
        vehicle1 = new Vehicle();
        vehicle1.setMarca("BMV");
        vehicle1.setPotencia(136);
        vehicle1.setVelocitatMaxima(210);
        System.out.print("Vehicle: marca=" + vehicle1.getMarca() + ", potència=" + vehicle1.getPotencia()); 
        System.out.println(", velocitat=" + vehicle1.getVelocitat() + ", velocitat màxima=" + vehicle1.getVelocitatMaxima());
        vehicle1.augmentarVelocitat(20);
        
        Vehicle vehicle2 = new Vehicle("Mercedes", 194, 50, 340);
        vehicle2.reduirVelocitat(10);       
        if (vehicle2.getVelocitatMaxima() >= vehicle1.getVelocitatMaxima()) {
            vehicle2.setVelocitat(vehicle1.getVelocitatMaxima());
        }
        System.out.println("Vehicle: marca=" + vehicle2.getMarca() + ", velocitat=" + vehicle2.getVelocitat());
        
    }
}
